namespace rt {

class Point;

int julia(const Point& v, const Point& c);

}
