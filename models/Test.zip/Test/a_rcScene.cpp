#include <core/image.h>
#include <core/color.h>
#include <core/random.h>

#include <rt/world.h>   
#include <rt/renderer.h>
#include <rt/loaders/obj.h>
#include <rt/integrators/recraytrace.h>
#include <rt/integrators/raytrace.h>
#include <rt/integrators/casting.h>

#include <rt/groups/simplegroup.h>
#include <rt/groups/bvh.h>

#include <rt/cameras/perspective.h>
#include <rt/cameras/dofperspective.h>
#include <rt/solids/quad.h>
#include <rt/solids/sphere.h>
#include <rt/solids/triangle.h>
#include <rt/solids/disc.h>
#include <rt/textures/constant.h>
#include <rt/textures/imagetex.h>
#include <rt/textures/perlin.h>

#include <rt/materials/flatmaterial.h>
#include <rt/materials/lambertian.h>
#include <rt/materials/fuzzymirror.h>
#include <rt/materials/glass.h>
#include <rt/materials/phong.h>
#include <rt/materials/combine.h>
#include <rt/materials/cooktorrance.h>
#include <rt/materials/mirror.h>
#include <rt/materials/dummy.h>

#include <rt/lights/arealight.h>
#include <rt/lights/pointlight.h>
#include <rt/lights/spotlight.h>
#include <rt/lights/directional.h>

#include <algorithm>

using namespace rt;

/*MatLib* getManMatlib() {
    MatLib* matlib = new MatLib;
    Texture* black = new ConstantTexture(RGBColor::rep(0.0f));

    ImageTexture* body = new ImageTexture("models/body.png");
    //LambertianMaterial* mat = new LambertianMaterial(black, body);

    ImageTexture* shoe = new ImageTexture("models/shoe.png");
    ImageTexture* bottom = new ImageTexture("models/bottom.png");
    ImageTexture* top = new ImageTexture("models/top.png");
    ImageTexture* goggles = new ImageTexture("models/g.png");
    ImageTexture* hair = new ImageTexture("models/hair.png");
    ImageTexture* lens = new ImageTexture("models/g.png");

    matlib->insert(std::pair<std::string, Material*>("mat0.007", new LambertianMaterial(black, body)));
    matlib->insert(std::pair<std::string, Material*>("mat0.008", new LambertianMaterial(black, shoe)));
    matlib->insert(std::pair<std::string, Material*>("mat0.009", new LambertianMaterial(black, bottom)));
    matlib->insert(std::pair<std::string, Material*>("mat0.010", new LambertianMaterial(black, top)));
    matlib->insert(std::pair<std::string, Material*>("mat0.011", new LambertianMaterial(black, goggles)));
    matlib->insert(std::pair<std::string, Material*>("mat0.012", new LambertianMaterial(black, hair)));
    matlib->insert(std::pair<std::string, Material*>("mat0.013", new LambertianMaterial(black, lens)));

    return matlib;
}*/
MatLib* getManMatlib() {
    MatLib* matlib = new MatLib;
    Texture* black = new ConstantTexture(RGBColor::rep(0.0f));

    //Man
    ImageTexture* body = new ImageTexture("models/body.png");
    ImageTexture* shoe = new ImageTexture("models/shoe.png");
    ImageTexture* bottom = new ImageTexture("models/bottom.png");
    ImageTexture* top = new ImageTexture("models/top.png");
    ImageTexture* goggles = new ImageTexture("models/g.png");
    ImageTexture* hair = new ImageTexture("models/hair.png");
    ImageTexture* lens = new ImageTexture("models/g.png");

    matlib->insert(std::pair<std::string, Material*>("mat0.007", new FlatMaterial(body)));
    matlib->insert(std::pair<std::string, Material*>("mat0.008", new FlatMaterial(shoe)));
    matlib->insert(std::pair<std::string, Material*>("mat0.009", new FlatMaterial(bottom)));
    matlib->insert(std::pair<std::string, Material*>("mat0.010", new FlatMaterial(top)));
    matlib->insert(std::pair<std::string, Material*>("mat0.011", new FlatMaterial(goggles)));
    matlib->insert(std::pair<std::string, Material*>("mat0.012", new FlatMaterial(hair)));
    matlib->insert(std::pair<std::string, Material*>("mat0.013", new FlatMaterial(lens)));

    ImageTexture* tyres = new ImageTexture("models/Material.008_baseColor.png");
    ImageTexture* body1 = new ImageTexture("models/Material.001_baseColor.jpeg");
    ImageTexture* interior = new ImageTexture("models/Material.002_baseColor.jpeg");

    matlib->insert(std::pair<std::string, Material*>("Material.003", new FlatMaterial(tyres)));
    matlib->insert(std::pair<std::string, Material*>("Material.008", new FlatMaterial(body1)));
    matlib->insert(std::pair<std::string, Material*>("Material.009", new FlatMaterial(interior)));

    return matlib;
}

/*MatLib* getRcarMatlib() {
    MatLib* matlib = new MatLib;
    Texture* black = new ConstantTexture(RGBColor::rep(0.0f));

    //rCar
    ImageTexture* tyres = new ImageTexture("models/Material.008_baseColor.png");
    ImageTexture* body = new ImageTexture("models/Material.001_baseColor.jpeg");
    ImageTexture* interior = new ImageTexture("models/Material.002_baseColor.jpeg");

    matlib->insert(std::pair<std::string, Material*>("Material.003", new FlatMaterial(tyres)));
    matlib->insert(std::pair<std::string, Material*>("Material.008", new FlatMaterial(body)));
    matlib->insert(std::pair<std::string, Material*>("Material.009", new FlatMaterial(interior)));


    return matlib;
}*/



void a_rcScene() {
    int scale = 2;
    Image img(400* scale, 300* scale);

    World world;
    BVH* scene = new BVH();
    //SimpleGroup* scene = new SimpleGroup();
    world.scene = scene;
    //SimpleGroup* scene = new SimpleGroup();

    MatLib* matlib_man = getManMatlib();
    //loadOBJ(scene, "models/", "ma_c.obj", matlib_man);

    //t1obj
    loadOBJ(scene, "models/", "t14.obj");
    /*PerspectiveCamera cam1(Point(0.290003, 12.454437, 26.836720)
        , Point(0.285111, 12.175436, 25.876442) - Point(0.290003, 12.454437, 26.836720)
        , Vector(-0.001420, 0.960291, -0.278998), pi / 8, pi / 6);*/
    //MatLib* matlib_rcar = getRcarMatlib();
    //loadOBJ(scene, "models/", "t3_rcar.obj", matlib_rcar);
    PerspectiveCamera cam1(Point(-4.159183, 7.200943, 19.053799)
        , Point(-4.138824, 6.888608, 18.104046) - Point(-4.159183, 7.200943, 19.053799)
        , Vector(0.006694, 0.949972, -0.312264), pi / 8, pi / 6);
    
    //point Light
    float scale1 = 500;
    //world.light.push_back(new PointLight(Point(-5.36, 3.57, 6.28), RGBColor::rep(105.f)));
    world.light.push_back(new PointLight(Point(-5.36, 3.57, 6.28), RGBColor(0.434f, 1.000f , 0.078f * scale1)));
    world.light.push_back(new PointLight(Point(-7.36, 3.57, 6.28), RGBColor(0.132f * scale1, 0.027f * scale1, 1.000f)));
    world.light.push_back(new PointLight(Point(-2.36, 3.57, 6.28), RGBColor(0.897f, 0.075f * scale1, 1.000f)));

    //RayCastingIntegrator integrator(&world);
    //RayTracingIntegrator integrator(&world);
    RecursiveRayTracingIntegrator integrator(&world);
    scene->rebuildIndex();

    //Renderer engine1(&cam2, &integrator);
    Renderer engine1(&cam1, &integrator);
    //engine1.setSamples(5);
    engine1.render(img);
    img.writePNG("rc-t3_p.png");

}