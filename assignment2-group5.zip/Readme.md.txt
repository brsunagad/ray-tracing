Group 5
Operating system: Windows 11
Ide: Visual Studio 2019
cgray.exe and generated images are available in /out/build/x64-Debug/
pdf of theoritical sheet is also available in root